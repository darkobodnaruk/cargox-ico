var isElectron = false;
var ledgerPort = 8080;
