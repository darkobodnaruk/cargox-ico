=========
Contracts
=========

.. contents:: :local:

Introduction
============

This chapter describers Ethereum crowdsale smart contracts.

Preface
=======

* You must understand Ethereum blockchain and `Solidity smart contract programming <http://solidity.readthedocs.io/>`_ basics

* You must have a running Ethereum full node with JSON-RPC interface enabld

TODO
====
