============
Introduction
============

.. contents:: :local:

.. include:: ../../README.rst

