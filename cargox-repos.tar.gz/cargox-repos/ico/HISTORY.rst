=======
History
=======


0.1 (unreleased)
----------------

* First release on PyPI.

