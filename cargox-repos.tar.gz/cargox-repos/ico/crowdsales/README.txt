Crowdsale definitions go here.
